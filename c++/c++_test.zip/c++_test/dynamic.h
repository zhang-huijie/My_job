#ifndef __DYNAMIC_H_
#define __DYNAMIC_H_
void dynamic_a();
void dynamic_b();
void dynamic_c();
#endif