#include"dynamic.h"
using namespace std;
void dynamic_a()
{
  cout<<"this is in dynamic_a "<<endl;
}