#include "dynamic.h"
#include <iostream>

using namespace std;

int main() {
  dynamic_a();
  cout << "succ." << endl;
}